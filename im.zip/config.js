/**
 * ShopWT IM by shopwt.com
 */
var config = {};//数据库帐号设置

config['host']  	= 'localhost';//数据库地址
config['port']  	= '3306';//数据库端口
config['user']  	= 'longbasz';//数据库用户名
config['password']  	= 'longbajituan';//数据库密码
config['database']  	= 'b2b2c';//mysql数据库名
config['tablepre']  	= 'lbsz_';//表前缀
config['insecureAuth']  	= true;//兼容低版本
config['debug']  	= false;//默认false

exports.hostname = 'b2b2c.longbasz.cn';//把网址修改为你安装商城的域名，不要带http://及/
exports.port = 33;//服务器所用端口号,默认33
exports.config = config;
